import * as React from 'react';
import { PropertyControls, ControlType } from 'framer';
type Props = { trigger: any; target: any };

export class TestAnimate extends React.Component<Props> {
  render() {
    return <div style={style}>{this.props.target}</div>;
  }

  static propertyControls: PropertyControls<Props> = {
    trigger: { type: ControlType.ComponentInstance, title: 'Trigger' },
    target: { type: ControlType.ComponentInstance, title: 'Target' },
  };
}
const style: React.CSSProperties = {
  height: '100%',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  textAlign: 'center',
  color: '#8855FF',
  background: 'rgba(136, 85, 255, 0.1)',
  overflow: 'hidden',
};
