import * as React from 'react';
import { Size, PropertyControls, ControlType } from 'framer';

const style: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  height: '100%',
};

// Define type of property
interface Props extends Size {
  trigger: 'mount' | 'tap' | 'hover';
}

interface State {
  started: boolean;
}

export class Trigger extends React.Component<Props, State> {
  // Set default properties
  static defaultProps = {
    delay: 0,
    trigger: 'tap',
  };

  // Items shown in property panel
  static propertyControls: PropertyControls = {
    trigger: {
      type: ControlType.Enum,
      options: ['mount', 'tap', 'hover'],
      optionTitles: ['On Mount', 'On Tap', 'On Hover'],
      defaultValue: 'tap',
      title: 'Trigger',
    },
    delay: { type: ControlType.Number, title: 'Delay', min: 0, max: 5000 },
  };
  myRef: React.RefObject<HTMLDivElement>;

  constructor(props) {
    super(props);
    this.myRef = React.createRef();
    this.state = {
      started: false,
    };
  }

  componentDidMount() {
    if (this.myRef && this.props.trigger === 'mount') {
      window.requestAnimationFrame(() => this.setState({ started: true }));
    }
  }

  onTap() {
    if (this.myRef && this.props.trigger === 'tap') {
      window.requestAnimationFrame(() => this.setState({ started: true }));
    }
  }

  onHover() {
    if (this.myRef && this.props.trigger === 'hover') {
      window.requestAnimationFrame(() => this.setState({ started: true }));
    }
  }

  render() {
    if (
      !this.props.children ||
      React.Children.count(this.props.children) === 0
    ) {
      return <Placeholder text="Connect with a frame to animate →" />;
    }

    React.Children.forEach(this.props.children, child => {
      // child.props.visi = true;
      console.dir(child);
    });
    React.Children.forEach(this.props.children, child => renderTree(child));

    return (
      <div
        style={{
          ...style,
          overflow: 'hidden',
        }}
        onClick={() => this.onTap()}
        onMouseOver={() => this.onHover()}
      >
        Hello
      </div>
    );
  }
}

function walkTree(onEachChildren, childrenKey = 'children') {
  return function treeWalker(elem, level = 0) {
    onEachChildren(elem, level);
    if (elem.props[childrenKey]) {
      elem.props[childrenKey].forEach(item => treeWalker(item, level + 1));
    }
  };
}

// how to use
const renderTree = walkTree((elem, level) => {
  console.log(
    elem.type.name
      .toString()
      .padStart(level + elem.type.name.toString().length, '-'),
  );
});

function Placeholder(props: { text: string }) {
  return <div style={placeholder}>{props.text}</div>;
}

const placeholder: React.CSSProperties = {
  width: '100%',
  height: '100%',
  padding: 10,
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  textAlign: 'center',
  backgroundColor: '#8855FF22',
  color: '#8855FF',
};
